from setuptools import setup

setup(
    name ='daedukmuchim',
    version = '1.0.0',
    description = 'market-kurly',
    author = 'daedukmuchim team',
    author_email = None,
    url = None,
    py_modules = ['daedukmuchim']
)