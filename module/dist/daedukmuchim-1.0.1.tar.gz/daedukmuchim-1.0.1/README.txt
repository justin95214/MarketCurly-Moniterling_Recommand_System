MARKET_KURLY_ONLY
- Test module
- Team Daedukmuchim